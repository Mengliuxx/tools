using System;
using System.Collections.ObjectModel;
using Microsoft.Win32;
using System.Web;
using System.Windows.Forms;

// PuttyTabs is copyright 2006 Dietrich Raisin.
// The exact Licence is in Licence.txt.

namespace PuttyTabs
{
    public sealed class PuttySession
    {
        String sName;
        String sHost = "(unknown)";
        Form mainForm;

        public PuttySession(String sName, Form mainForm)
        {
            this.sName = sName;
            this.mainForm = mainForm;
        }

        public String Name
        {
            get { return sName; }
        }

        public String DisplayName
        {
            get { return HttpUtility.UrlDecode(sName); }
        }

        public Form MainForm
        {
            get { return mainForm; }
        }

        public String Host
        {
            get { return sHost; }
            set { sHost = value; }
        }
    }
    
    public sealed class PuttySessionCollection
    {
        String sFingerprint = "";
        Collection<PuttySession> sessions = new Collection<PuttySession>();
        Form mainForm;

        public PuttySessionCollection(Form mainForm)
        {
            this.mainForm = mainForm;
        }

        public String Fingerprint
        {
            get { return sFingerprint; }
        }

        public String getRegistryFingerprint()
        {
            return _fetchSessions(true);
        }

        public String fetchSessionsFromRegistry()
        {
            return _fetchSessions(false);
        }

        private String _fetchSessions(bool onlyFingerprint)
        {
            if (!onlyFingerprint)
            {
                sessions.Clear();
            }

            string subkeyM = @"Software\SimonTatham\PuTTY\Sessions";

            RegistryKey rk = Registry.CurrentUser.OpenSubKey(subkeyM);
            if (rk == null) return "";

            string fingerprint = "";
            foreach (string subKeyName in rk.GetSubKeyNames())
            {
                RegistryKey tempKey = rk.OpenSubKey(subKeyName);
                Object hostName = (tempKey != null) ? tempKey.GetValue("HostName") : null;
                String sHost = (hostName != null) ? hostName.ToString() : "";

                if (!onlyFingerprint)
                {
                    PuttySession session = new PuttySession(subKeyName, mainForm);
                    session.Host = sHost;
                    sessions.Add(session);
                }

                fingerprint += subKeyName + "\0" + sHost + "\0";
            }
            if (!onlyFingerprint)
            {
                sFingerprint = fingerprint;
            }
            return fingerprint;
        }

        public Collection<PuttySession> getSessions()
        {
            return sessions;
        }
    }
}