﻿namespace PuttyTabs
{
    partial class ConfigForm
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConfigForm));
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.cancelButton = new System.Windows.Forms.Button();
            this.okButton = new System.Windows.Forms.Button();
            this.filenameTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.alwaysOnTopCheckBox = new System.Windows.Forms.CheckBox();
            this.moveOutOfViewCheckBox = new System.Windows.Forms.CheckBox();
            this.importPuttyProcessesCheckBox = new System.Windows.Forms.CheckBox();
            this.hidePuttyProcessesCheckBox = new System.Windows.Forms.CheckBox();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.AddExtension = false;
            this.openFileDialog1.FileName = "openFileDialog1";
            this.openFileDialog1.Filter = "putty.exe|putty.exe|All exe|*.exe|All files|*.*";
            this.openFileDialog1.Title = "Where is your \"putty.exe\"?";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.flowLayoutPanel1.AutoSize = true;
            this.flowLayoutPanel1.Controls.Add(this.cancelButton);
            this.flowLayoutPanel1.Controls.Add(this.okButton);
            this.flowLayoutPanel1.FlowDirection = System.Windows.Forms.FlowDirection.RightToLeft;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(12, 193);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(554, 39);
            this.flowLayoutPanel1.TabIndex = 0;
            // 
            // cancelButton
            // 
            this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.cancelButton.Location = new System.Drawing.Point(476, 3);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 33);
            this.cancelButton.TabIndex = 1;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // okButton
            // 
            this.okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.okButton.Location = new System.Drawing.Point(395, 3);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 33);
            this.okButton.TabIndex = 0;
            this.okButton.Text = "OK";
            this.okButton.UseVisualStyleBackColor = true;
            // 
            // filenameTextBox
            // 
            this.filenameTextBox.Location = new System.Drawing.Point(12, 37);
            this.filenameTextBox.Name = "filenameTextBox";
            this.filenameTextBox.Size = new System.Drawing.Size(458, 22);
            this.filenameTextBox.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Where is your \"putty.exe\"?";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(485, 32);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(81, 33);
            this.button1.TabIndex = 3;
            this.button1.Text = "Search...";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // alwaysOnTopCheckBox
            // 
            this.alwaysOnTopCheckBox.AutoSize = true;
            this.alwaysOnTopCheckBox.Location = new System.Drawing.Point(12, 84);
            this.alwaysOnTopCheckBox.Name = "alwaysOnTopCheckBox";
            this.alwaysOnTopCheckBox.Size = new System.Drawing.Size(117, 21);
            this.alwaysOnTopCheckBox.TabIndex = 4;
            this.alwaysOnTopCheckBox.Text = "Always on top";
            this.alwaysOnTopCheckBox.UseVisualStyleBackColor = true;
            // 
            // moveOutOfViewCheckBox
            // 
            this.moveOutOfViewCheckBox.AutoSize = true;
            this.moveOutOfViewCheckBox.Location = new System.Drawing.Point(12, 111);
            this.moveOutOfViewCheckBox.Name = "moveOutOfViewCheckBox";
            this.moveOutOfViewCheckBox.Size = new System.Drawing.Size(222, 21);
            this.moveOutOfViewCheckBox.TabIndex = 5;
            this.moveOutOfViewCheckBox.Text = "Move out of view when docked";
            this.moveOutOfViewCheckBox.UseVisualStyleBackColor = true;
            // 
            // importPuttyProcessesCheckBox
            // 
            this.importPuttyProcessesCheckBox.AutoSize = true;
            this.importPuttyProcessesCheckBox.Location = new System.Drawing.Point(12, 138);
            this.importPuttyProcessesCheckBox.Name = "importPuttyProcessesCheckBox";
            this.importPuttyProcessesCheckBox.Size = new System.Drawing.Size(286, 21);
            this.importPuttyProcessesCheckBox.TabIndex = 6;
            this.importPuttyProcessesCheckBox.Text = "Import running PuTTY processes at start";
            this.importPuttyProcessesCheckBox.UseVisualStyleBackColor = true;
            // 
            // hidePuttyProcessesCheckBox
            // 
            this.hidePuttyProcessesCheckBox.AutoSize = true;
            this.hidePuttyProcessesCheckBox.Location = new System.Drawing.Point(12, 165);
            this.hidePuttyProcessesCheckBox.Name = "hidePuttyProcessesCheckBox";
            this.hidePuttyProcessesCheckBox.Size = new System.Drawing.Size(370, 21);
            this.hidePuttyProcessesCheckBox.TabIndex = 7;
            this.hidePuttyProcessesCheckBox.Text = "Hide PuTTY processes from task bar (experimental !!!)";
            this.hidePuttyProcessesCheckBox.UseVisualStyleBackColor = true;
            this.hidePuttyProcessesCheckBox.Visible = false;
            // 
            // ConfigForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(578, 244);
            this.Controls.Add(this.hidePuttyProcessesCheckBox);
            this.Controls.Add(this.importPuttyProcessesCheckBox);
            this.Controls.Add(this.moveOutOfViewCheckBox);
            this.Controls.Add(this.alwaysOnTopCheckBox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.filenameTextBox);
            this.Controls.Add(this.flowLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ConfigForm";
            this.ShowInTaskbar = false;
            this.Text = "Configuration";
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.TextBox filenameTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox alwaysOnTopCheckBox;
        private System.Windows.Forms.CheckBox moveOutOfViewCheckBox;
        private System.Windows.Forms.CheckBox importPuttyProcessesCheckBox;
        private System.Windows.Forms.CheckBox hidePuttyProcessesCheckBox;
    }
}