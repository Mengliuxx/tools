using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PuttyTabs
{
    public partial class AboutForm : Form
    {
        public AboutForm()
        {
            InitializeComponent();
        }

        public void show()
        {
            //filenameTextBox.Text = Config.getStringValue("PuttyExe");

            aboutLabel.Text =
                "This is PuttyTabs " + Application.ProductVersion + "\r\n\r\n"
                + "PuTTY, a very fine program by Simon Tatham, has one thing missing: tabs.\r\n"
                + "This tool, PuttyTabs, adds this feature.\r\n\r\n"
                + "Enjoy, it's freeware!\r\n\r\n"
                + "Dietrich Raisin, info1@raisin.de, www.raisin.de"
            ;

            DialogResult result = this.ShowDialog();
        }

        private void checkForNewVersionButton_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.raisin.de/putty-tabs/putty-tabs.html");
        }
    }
}