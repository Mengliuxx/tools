using System;
using System.Collections.Generic;
using System.Text;

using System.Windows.Forms;
using System.Runtime.InteropServices;

// PuttyTabs is copyright 2006 Dietrich Raisin.
// The exact Licence is in Licence.txt.

// Some Code snippets are from:
// http://svn.myrealbox.com/source/trunk/mcs/class/Managed.Windows.Forms/System.Windows.Forms/XplatUIWin32.cs
// And from here:
// http://www.codeproject.com/csharp/winconsole.asp

namespace PuttyTabs
{
    class Win32Window
    {
        IntPtr hWnd;

        #region Enums, Struct Defs and DllImports

        [StructLayout(LayoutKind.Sequential)]
        private struct RECT
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
            public override string ToString()
            {
                return ("Left :" + left.ToString() + "," + "Top :" + top.ToString() + "," + "Right :" + right.ToString() + "," + "Bottom :" + bottom.ToString());
            }
        }

        [Flags]
        enum WindowLong
        {
            GWL_WNDPROC = -4,
            GWL_HINSTANCE = -6,
            GWL_HWNDPARENT = -8,
            GWL_STYLE = -16,
            GWL_EXSTYLE = -20,
            GWL_USERDATA = -21,
            GWL_ID = -12
        }

        enum WindowPlacementFlags
        {
            SW_HIDE = 0,
            SW_SHOWNORMAL = 1,
            SW_NORMAL = 1,
            SW_SHOWMINIMIZED = 2,
            SW_SHOWMAXIMIZED = 3,
            SW_MAXIMIZE = 3,
            SW_SHOWNOACTIVATE = 4,
            SW_SHOW = 5,
            SW_MINIMIZE = 6,
            SW_SHOWMINNOACTIVE = 7,
            SW_SHOWNA = 8,
            SW_RESTORE = 9,
            SW_SHOWDEFAULT = 10,
            SW_FORCEMINIMIZE = 11,
            SW_MAX = 11
        }

        enum SetWindowPosZOrder
        {
            HWND_TOP = 0,
            HWND_BOTTOM = 1,
            HWND_TOPMOST = -1,
            HWND_NOTOPMOST = -2
        }

        [Flags]
        enum SetWindowPosFlags
        {
            SWP_ASYNCWINDOWPOS = 0x4000,
            SWP_DEFERERASE = 0x2000,
            SWP_DRAWFRAME = 0x0020,
            SWP_FRAMECHANGED = 0x0020,
            SWP_HIDEWINDOW = 0x0080,
            SWP_NOACTIVATE = 0x0010,
            SWP_NOCOPYBITS = 0x0100,
            SWP_NOMOVE = 0x0002,
            SWP_NOOWNERZORDER = 0x0200,
            SWP_NOREDRAW = 0x0008,
            SWP_NOREPOSITION = 0x0200,
            SWP_NOENDSCHANGING = 0x0400,
            SWP_NOSIZE = 0x0001,
            SWP_NOZORDER = 0x0004,
            SWP_SHOWWINDOW = 0x0040
        }

        enum WindowStyles : uint
        {
            WS_OVERLAPPED = 0x00000000,
            WS_POPUP = 0x80000000,
            WS_CHILD = 0x40000000,
            WS_MINIMIZE = 0x20000000,
            WS_VISIBLE = 0x10000000,
            WS_DISABLED = 0x08000000,
            WS_CLIPSIBLINGS = 0x04000000,
            WS_CLIPCHILDREN = 0x02000000,
            WS_MAXIMIZE = 0x01000000,
            WS_CAPTION = 0x00C00000,
            WS_BORDER = 0x00800000,
            WS_DLGFRAME = 0x00400000,
            WS_VSCROLL = 0x00200000,
            WS_HSCROLL = 0x00100000,
            WS_SYSMENU = 0x00080000,
            WS_THICKFRAME = 0x00040000,
            WS_GROUP = 0x00020000,
            WS_TABSTOP = 0x00010000,
            WS_MINIMIZEBOX = 0x00020000,
            WS_MAXIMIZEBOX = 0x00010000,
            WS_TILED = 0x00000000,
            WS_ICONIC = 0x20000000,
            WS_SIZEBOX = 0x00040000,
            WS_POPUPWINDOW = 0x80880000,
            WS_OVERLAPPEDWINDOW = 0x00CF0000,
            WS_TILEDWINDOW = 0x00CF0000,
            WS_CHILDWINDOW = 0x40000000
        }

        enum WindowExStyles : uint
        {
            WS_EX_DLGMODALFRAME = 0x00000001,
            WS_EX_NOPARENTNOTIFY = 0x00000004,
            WS_EX_TOPMOST = 0x00000008,
            WS_EX_ACCEPTFILES = 0x00000010,
            WS_EX_TRANSPARENT = 0x00000020,
            WS_EX_MDICHILD = 0x00000040,
            WS_EX_TOOLWINDOW = 0x00000080,
            WS_EX_WINDOWEDGE = 0x00000100,
            WS_EX_CLIENTEDGE = 0x00000200,
            WS_EX_CONTEXTHELP = 0x00000400,
            WS_EX_RIGHT = 0x00001000,
            WS_EX_LEFT = 0x00000000,
            WS_EX_RTLREADING = 0x00002000,
            WS_EX_LTRREADING = 0x00000000,
            WS_EX_LEFTSCROLLBAR = 0x00004000,
            WS_EX_RIGHTSCROLLBAR = 0x00000000,
            WS_EX_CONTROLPARENT = 0x00010000,
            WS_EX_STATICEDGE = 0x00020000,
            WS_EX_APPWINDOW = 0x00040000,
            WS_EX_OVERLAPPEDWINDOW = 0x00000300,
            WS_EX_PALETTEWINDOW = 0x00000188,
            WS_EX_LAYERED = 0x00080000
        }

        [DllImport("user32.dll", EntryPoint = "GetWindowLong", CallingConvention = CallingConvention.StdCall)]
        private extern static uint Win32GetWindowLong(IntPtr hwnd, WindowLong index);

        [DllImport("user32.dll", EntryPoint = "SetWindowLong", CallingConvention = CallingConvention.StdCall)]
        private extern static uint Win32SetWindowLong(IntPtr hwnd, WindowLong index, uint value);

        [DllImport("User32.dll", EntryPoint = "ShowWindow", CharSet = CharSet.Auto)]
        private static extern bool Win32ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll", EntryPoint = "GetWindowRect", CharSet = CharSet.Auto)]
        private extern static bool Win32GetWindowRect(IntPtr hwnd, ref RECT lpRect);

        [DllImport("user32.dll", EntryPoint = "MoveWindow", CharSet = CharSet.Auto)]
        private extern static bool Win32MoveWindow(IntPtr hwnd, int x, int y, int w, int h, bool bRepaint);

        [DllImport("user32.dll", EntryPoint = "SetWindowPos", CharSet = CharSet.Auto)]
        private extern static bool Win32SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int x, int y, int cx, int cy, SetWindowPosFlags Flags);

        [DllImport("user32.dll", EntryPoint = "GetActiveWindow", CallingConvention = CallingConvention.StdCall)]
        private extern static IntPtr Win32GetActiveWindow();

        [DllImport("user32.dll", EntryPoint = "GetForegroundWindow", CallingConvention = CallingConvention.StdCall)]
        private extern static IntPtr Win32GetForegroundWindow();

        [DllImport("user32.dll", EntryPoint = "SetParent", CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr Win32SetParent(IntPtr hwnd, IntPtr hwnd2);

        [DllImport("user32.dll", EntryPoint = "GetParent", CallingConvention = CallingConvention.StdCall)]
        private static extern IntPtr Win32GetParent(IntPtr hwnd);

		[DllImport("user32.dll", EntryPoint="SetWindowTextW", CharSet=CharSet.Unicode, CallingConvention=CallingConvention.StdCall)]
		internal extern static bool Win32SetWindowText(IntPtr hWnd, string lpString);

		[DllImport("user32.dll", EntryPoint="GetWindowTextW", CharSet=CharSet.Unicode, CallingConvention=CallingConvention.StdCall)]
		internal extern static bool Win32GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);

        #endregion

        public Win32Window(IntPtr hWnd)
        {
            this.hWnd = hWnd;
        }

        public static IntPtr getActiveWindow()
        {
            return Win32GetActiveWindow();
        }

        public static IntPtr getForegroundWindow()
        {
            return Win32GetForegroundWindow();
        }

        public FormWindowState State
        {
            get
            {
                uint style;

                style = Win32GetWindowLong(hWnd, WindowLong.GWL_STYLE);
                if ((style & (uint)WindowStyles.WS_MAXIMIZE) != 0)
                {
                    return FormWindowState.Maximized;
                }   
                if ((style & (uint)WindowStyles.WS_MINIMIZE) != 0)
                {
                    return FormWindowState.Minimized;
                }
                return FormWindowState.Normal;
            }
            set 
            {
			    if (value == FormWindowState.Normal) {
					Win32ShowWindow(hWnd, (int)WindowPlacementFlags.SW_RESTORE);
					return;
				}
			    if (value == FormWindowState.Minimized) {
					Win32ShowWindow(hWnd, (int)WindowPlacementFlags.SW_MINIMIZE);
					return;
				}
			    if (value == FormWindowState.Maximized) {
					Win32ShowWindow(hWnd, (int)WindowPlacementFlags.SW_MAXIMIZE);
					return;
				}
			}
		}

        public String Title
        {
            get {
                StringBuilder sb = new StringBuilder(100);
                Win32GetWindowText(hWnd, sb, 100);
                return sb.ToString();
            }
            set {
                Win32SetWindowText(hWnd, value);
            }
        }

        public void hideFromTaskSwitcher()
        {
            Win32SetWindowLong(hWnd, WindowLong.GWL_EXSTYLE
                    , (Win32GetWindowLong(hWnd, WindowLong.GWL_EXSTYLE)
                         & (uint)~(WindowExStyles.WS_EX_APPWINDOW)) | (uint)WindowExStyles.WS_EX_TOOLWINDOW);
        }

        public IntPtr ParentHandle
        {
            get
            {
                return Win32GetParent(hWnd);
            }
            set
            {
                // Don't do this at the mo because:
                // - I don't really know how to do it...
                // - If PuttyTabs crashes, who will restore the putty windows?
                // - Hidden apps can be confused with spy ware.

                // IntPtr hwnd = Handle;
                // if (hwnd == IntPtr.Zero)
                //     return;
/*
                Win32SetWindowLong(hWnd, WindowLong.GWL_EXSTYLE
                    , (Win32GetWindowLong(hWnd, WindowLong.GWL_EXSTYLE)
                         & (uint)~(WindowExStyles.WS_EX_APPWINDOW)) | (uint)WindowExStyles.WS_EX_TOOLWINDOW);

                return;

                SetWindowLong(mWnd, GWL_EXSTYLE, (GetWindowLong(mWnd, GWL_EXSTYLE)
                    & ~(WS_EX_TOOLWINDOW)) | WS_EX_APPWINDOW);

*/

//                Win32SetParent(hWnd, value);

                /*
                uint style = Win32GetWindowLong(hWnd, WindowLong.GWL_STYLE);
                if (value == IntPtr.Zero)
                    Win32SetWindowLong(hWnd, WindowLong.GWL_STYLE, (style & (uint)~WindowStyles.WS_CHILD) | (uint)WindowStyles.WS_OVERLAPPEDWINDOW);
                else
                    Win32SetWindowLong(hWnd, WindowLong.GWL_STYLE, (style | (uint)WindowStyles.WS_CHILD) & (uint)~WindowStyles.WS_OVERLAPPEDWINDOW);
                */
                // Win32SetWindowPos(hWnd, IntPtr.Zero, 0, 0, 0, 0, SetWindowPosFlags.SWP_NOSIZE | SetWindowPosFlags.SWP_NOZORDER | SetWindowPosFlags.SWP_NOACTIVATE);

            }
        }

        public void setSize(int left, int top, int width, int height)
        {
            bool result = Win32MoveWindow(hWnd, left, top, width, height, true);
            // Console.WriteLine("MoveWindow: " + result.ToString());
        }

        public void bringToFront()
        {
            int zOrder = (int)SetWindowPosZOrder.HWND_TOP;
            IntPtr zOrder2 = (IntPtr)zOrder;
            Win32SetWindowPos(hWnd, zOrder2, 0, 0, 0, 0, SetWindowPosFlags.SWP_NOMOVE | SetWindowPosFlags.SWP_NOSIZE);
        }
    }

}
