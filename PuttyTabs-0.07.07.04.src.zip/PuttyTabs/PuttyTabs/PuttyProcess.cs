using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.Diagnostics;
using System.Web;
using System.Threading;
using System.Collections.ObjectModel;

// PuttyTabs is copyright 2006 Dietrich Raisin.
// The exact Licence is in Licence.txt.

namespace PuttyTabs
{
    public enum PuttyProcessState { exited, started, active };
    
    public sealed class PuttyProcess
    {
        static bool changed;

        PuttyProcessState lastCheckedState;

        PuttySession session;
        Process process;
        String tag = "";
        String lastDisplayName = "";

        public PuttyProcess(PuttySession session)
        {
            this.session = session;
        }

        public PuttyProcess(Process process)
        {
            this.process = process;
        }

        public PuttySession Session
        {
            get { return session; }
        }

        public Process Process
        {
            get { return process; }
        }

        public String Tag
        {
            get { return tag; }
            set { tag = value; }
        }

        public String DisplayName
        {
            get
            {
                String result = session == null ? "" : session.DisplayName;
                if (tag != "") result += (result != "") ? " (" + tag + ")" : tag;
                if (process != null)
                {
                    Win32Window window = new Win32Window(process.MainWindowHandle);
                    String title = window.Title; // process.MainWindowTitle;
                    if (title != "") result += (result != "") ? ":\r\n" + title : title;
                }
                if (result == "") result= "(Unknown)";
                if (result.Length <= 50) return result;
                return result.Substring(0, 50) + "...";
            }
        }

        private void startProcess(String sName)
        {
            process = new Process();
            try
            {
                process.StartInfo.FileName = Config.getStringValue("PuttyExe");
                process.StartInfo.Arguments = (sName == "") ? "" : "-load \"" + HttpUtility.UrlDecode(sName) + "\"";
                process.StartInfo.CreateNoWindow = true;
                process.Start();
            }
            catch (Win32Exception e)
            {
                MessageBox.Show("An error occured while launching PuTTY. Please check your configuration!\n\r"
                    + "\n\r\"" + e.Message + "\"", "Can't launch PuTTY",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        // Is this a Bug in Dotnet? If I fetch MainWindowHandle immediatly after
        // creating the process, it returns 0. But it will always stay 0 for
        // any later call. So I fetch it directly:
        private IntPtr ProcessMainWindowHandle {
            get
            {
                try
                {
                    return Process.GetProcessById(process.Id).MainWindowHandle;
                }
                catch
                {
                    return new IntPtr();
                }
            }
        }
        
        public bool isMinimized()
        {
        	Win32Window window = new Win32Window(ProcessMainWindowHandle);

			if (window.State == FormWindowState.Minimized)
			{
				return true;
			}
			
			return false;
        }

        public void startOrActivate()
        {
            if (isStarted())
            {
                Win32Window window = new Win32Window(ProcessMainWindowHandle);
                if (window.State == FormWindowState.Minimized)
                {
                    window.State= FormWindowState.Normal;
                }
                window.bringToFront();
                window.ParentHandle = process.MainWindowHandle; //  session.MainForm.Handle;
            }
            else
            {
                start();
            }
        }
        
        public void toBackground()
        {
        	if (isStarted())
        	{
        		Win32Window window = new Win32Window(ProcessMainWindowHandle);
        		
        		if (window.State != FormWindowState.Minimized)
        		{
        			window.State = FormWindowState.Minimized;
        		}
        	}
        }

        private bool isStarted()
        {
            if (process == null) return false;
            if (process.HasExited) return false;
            return true;
        }

        public void start()
        {
            startProcess(session.Name);
            process.WaitForInputIdle(1000);
            Thread.Sleep(500); // Trying to fix problems with MainWindowHandle
        }

        public PuttyProcessState State
        {
            get { return getState(); }
        }

        private PuttyProcessState getState()
        {
            PuttyProcessState state = PuttyProcessState.exited;
            if (process != null && !process.HasExited)
            {
                if (ProcessMainWindowHandle == Win32Window.getForegroundWindow())
                {
                    state = PuttyProcessState.active;
                }
                else
                {
                    state = PuttyProcessState.started;
                }
            }
            return state;
        }


        public void checkChanged() 
        {
            PuttyProcessState state= getState();
            if (lastCheckedState != state)
            {
                lastCheckedState = state;
                changed = true;
            }
            if (lastDisplayName != DisplayName)
            {
                lastDisplayName = DisplayName;
                changed = true;
            }
        }

        public static bool hasChanged
        {
            get { bool temp = changed; changed = false; return temp; }
        }
    }


    // I think this should be a derived from Collection.
    // But I don't know how to do that. I'll look it up later.
    public sealed class PuttyProcessCollection
    {
        Collection<PuttyProcess> processes = new Collection<PuttyProcess>();

        public Collection<PuttyProcess> getProcesses()
        {
            return processes;
        }

        public void move(int from, int to) {
            if (from >= processes.Count || to >= processes.Count) return;

            PuttyProcess temp = processes[from];
            processes.RemoveAt(from);
            // processes.Insert(to > from ? to - 1 : to, temp);
            processes.Insert(to, temp);
        }

        public void startProcess(PuttySession session)
        {
            PuttyProcess puttyProcess = new PuttyProcess(session);
            puttyProcess.start();
            processes.Add(puttyProcess);
        }

        public void activateProcess(int processIndex)
        {
            if (processIndex < 0 || processIndex >= processes.Count) return;

            processes[processIndex].startOrActivate();
        }

        public void startProcess(Form mainForm)
        {
            startProcess(new PuttySession("Unnamed", mainForm));
        }

        // http://de.wikipedia.org/wiki/Farbtabellen_im_Internet

        public bool processHasChanged()
        {
            for (int i= processes.Count-1; i >= 0; i--)
            {
                processes[i].checkChanged();
                if (processes[i].State == PuttyProcessState.exited)
                {
                    processes.RemoveAt(i);
                }
            }
            foreach (PuttyProcess puttyProcess in processes)
            {
                puttyProcess.checkChanged();
            }
            return PuttyProcess.hasChanged;
        }

        public void fetchRunningPuttys()
        {
            Process[] processRunning = Process.GetProcesses();
            
            // don't attempt to do anything if not configured - stops an exception later
            if (Config.getStringValue("PuttyExe") == "")
            	return;
            
            foreach (Process process in processRunning)
            {
                if ((int)process.MainWindowHandle == 0) continue;
                
                // ok, this is still throwing exceptions. stop them all.
                try
                {
                	if (process.MainModule.FileName != Config.getStringValue("PuttyExe")) continue;
					PuttyProcess puttyProcess = new PuttyProcess(process);
                	processes.Add(puttyProcess);
                }
                catch
                {
                	; // deliberatly empty
                }
            }
        }
    }
}
