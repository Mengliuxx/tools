using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

// PuttyTabs is copyright 2006 Dietrich Raisin.
// The exact Licence is in Licence.txt.

namespace PuttyTabs
{
    public partial class ConfigForm : Form
    {
        public ConfigForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            openFileDialog1.FileName = filenameTextBox.Text;
            DialogResult result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                filenameTextBox.Text = openFileDialog1.FileName;
            }
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        public void show()
        {
            filenameTextBox.Text= Config.getStringValue("PuttyExe");
            alwaysOnTopCheckBox.Checked = Config.getIntValue("alwaysOnTop") != 0;
            moveOutOfViewCheckBox.Checked = Config.getIntValue("moveOutOfView") != 0;
            importPuttyProcessesCheckBox.Checked = Config.getIntValue("importPuttyProcesses") != 0;
            hidePuttyProcessesCheckBox.Checked = Config.getIntValue("hidePuttyProcesses") != 0;
            DialogResult result = this.ShowDialog();
            if (result == DialogResult.OK)
            {
                Config.setStringValue("PuttyExe", filenameTextBox.Text);
                Config.setIntValue("alwaysOnTop", alwaysOnTopCheckBox.Checked ? 1 : 0);
                Config.setIntValue("moveOutOfView", moveOutOfViewCheckBox.Checked ? 1 : 0);
                Config.setIntValue("importPuttyProcesses", importPuttyProcessesCheckBox.Checked ? 1 : 0);
                Config.setIntValue("hidePuttyProcesses", hidePuttyProcessesCheckBox.Checked ? 1 : 0);
            }
        }
    }
}