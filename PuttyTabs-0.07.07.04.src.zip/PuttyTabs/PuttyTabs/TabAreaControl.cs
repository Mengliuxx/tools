using System;
using System.Collections.Generic;
using System.Text;
using System.Collections.ObjectModel;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Drawing;

// PuttyTabs is copyright 2006 Dietrich Raisin.
// The exact Licence is in Licence.txt.

namespace PuttyTabs
{
    struct TabArea
    {
        public Rectangle rectangle;
        public int boxHeight;
        public PuttyProcess process;
    }

    class TabAreaControl
    {
        Collection<TabArea> tabAreas;
        Control tabControl;
        int tabMaxHeight;
        int activeTab = -1;
        const int r = 5;
        const int TABHEIGHT_EXTRA = 10;

        int dragStartX;
        int dragStartY;
        int dragFrom = -1;
        int dragOverTab = -1;
        bool dragStarted;

        static TextFormatFlags textFormatFlags = TextFormatFlags.NoPrefix
            | TextFormatFlags.TextBoxControl
            | TextFormatFlags.WordBreak
            | TextFormatFlags.LeftAndRightPadding
        ;

        public TabAreaControl(Control tabControl)
        {
            this.tabControl = tabControl;

            Graphics g = tabControl.CreateGraphics();
            Size size = TextRenderer.MeasureText(g, "Ig", tabControl.Font, new Size(120, 20), textFormatFlags);
            tabMaxHeight = size.Height * 2;

            activeTab = calcMouseoverTab();
        }

        public int ActiveTab
        {
            get { return activeTab; }
        }

        public PuttyProcess ActiveProcess
        {
            get
            {
                if (activeTab < 0) return null;
                return tabAreas[activeTab].process;
            }
        }

        public void updateActiveTab()
        {
            int oldActiveTab = activeTab;
            activeTab = calcMouseoverTab();
            if (activeTab != oldActiveTab) tabControl.Invalidate();
        }

        private int calcMouseoverTab()
        {
            if (tabAreas == null) return -1;
            int i = 0;
            foreach (TabArea tabArea in tabAreas)
            {
                // Calc Screen Position of TabArea
                Rectangle rectangle = new Rectangle(
                    tabControl.PointToScreen(new Point(tabArea.rectangle.Left, tabArea.rectangle.Top)),
                    new Size(tabArea.rectangle.Width, tabArea.rectangle.Height)
                );
                // Console.WriteLine(tabArea.rectangle.ToString() + ':' + rectangle.ToString() + ':' + Control.MousePosition.ToString());
                if (rectangle.Contains(Control.MousePosition))
                {
                    return i;
                }
                i++;
            }
            return -1;
        }

        // Helper function for paint
        private void fillBg(Graphics g, GraphicsPath gp, int x, int y, int w, int h, bool forMainFormRegion)
        {
            gp.Reset(); 
            if (forMainFormRegion)
            {
                gp.AddRectangle(new Rectangle(x, y, w, h > 5 ? h : 1));
                return;
            }

            g.SmoothingMode = SmoothingMode.None;
            g.FillRectangle(Brushes.WhiteSmoke, new Rectangle(x, y, w, h));

            gp.Reset();
            gp.AddLine(x, y, x + w, y);
            g.DrawPath(new Pen(Color.LightSlateGray), gp);
        }

        public void paint(Graphics g)
        {
            paint(g, null, false);
            // paint(g, gp, tabControl.Left + 1, tabControl.Top + 1);
        }

        public void paint(Graphics g, GraphicsPath gp2, bool forMainFormRegion)
        {
            GraphicsPath gp = new GraphicsPath();

            int left = 0;
            int top = 0;
            int width = tabControl.Width;
            int height = tabControl.Height;

            if (forMainFormRegion)
            {
                left = tabControl.Left + 1;
                top = tabControl.Top + 1;
            }

            int i = 0;
            foreach (TabArea tabArea in tabAreas)
            {
                int x = left + tabArea.rectangle.Left;
                int y = top + tabArea.rectangle.Top;
                int w = tabArea.rectangle.Width;
                int h = tabArea.rectangle.Height;
                int boxHeight = tabArea.boxHeight;

                fillBg(g, gp, x, y, w, boxHeight, forMainFormRegion);
                if (forMainFormRegion)
                {
                    gp2.AddPath(gp, false);
                }

                if (tabArea.process != null)
                {
                    Color color = (i == activeTab) ? color = Color.Pink : Color.White;
                    
                    if (tabArea.process.State == PuttyProcessState.active) {
                        color = (i == activeTab) ? color = Color.Goldenrod : Color.Gold;
                    }

                    Brush brush = new LinearGradientBrush(new Point(x, y), new Point(x, y + h), color, Color.PeachPuff);
                    String text = tabArea.process.DisplayName;

                    gp.Reset();
                    gp.AddRectangle(new Rectangle(x + 1, y + 1, w - 2, h + 1 - 4 - r));
                    gp.AddPie(x + 1, y + 2 + h - 4 - r * 2, r * 2, r * 2, -180, -90);
                    gp.AddRectangle(new Rectangle(x + r + 1, y + 2 + h - 4 - r, w - r * 2 - 2, r));
                    gp.AddPie(x + w - r * 2 - 1, y + 2 + h - 4 - r * 2, r * 2, r * 2, 90, -90);

                    Point [] dragPoly= { new Point(x - 8, y), new Point(x + 8, y), new Point(x, y + 10) };

                    if (forMainFormRegion)
                    {
                        if (boxHeight < 5) gp2.AddPath(gp, false);
                        if (i == dragOverTab) gp2.AddRectangle(new Rectangle(x - 1, y + 1, 2, 10));
                    }
                    else {
                        g.FillPath(brush, gp);
                        g.SmoothingMode = SmoothingMode.AntiAlias;

                        gp.Reset();
                        // gp.AddLine(x, y-1, x+1, y-1);
                        gp.AddLine(x + 1, y + 1, x + 1, y + h - 4 - r);
                        gp.AddArc(x + 1, y + h + 1 - 4 - r * 2, r * 2, r * 2, 180, -90);
                        gp.AddLine(x + r + 1, y + 1 + h - 4, x + w - r - 2, y + 1 + h - 4);
                        gp.AddArc(x + w - r * 2 - 2, y + 1 + h - 4 - r * 2, r * 2, r * 2, 90, -90);
                        gp.AddLine(x + w - 2, y + 1 + h - 4 - r, x + w - 2, y + 1);
                        // gp.AddLine(x+w-2, y-1, x+w-1, y-1);
                        Pen pen = new Pen(Color.LightSlateGray);
                        if (dragStarted && i == dragFrom)
                        {
                            pen.Brush = new SolidBrush(Color.Red);
                            pen.Width = 3;
                        }

                        g.DrawPath(pen, gp);

                        TextRenderer.DrawText(g, text, tabControl.Font
                            , new Rectangle(x, y, w, h), tabControl.ForeColor
                            , textFormatFlags | TextFormatFlags.EndEllipsis);

                        if (dragStarted && i == dragOverTab)
                        {
                            gp.Reset();
                            gp.AddPolygon(dragPoly);
                            brush = new SolidBrush(Color.Red);
                            g.FillPath(brush, gp);
                        }
                    }
                }
                i++;
            }
        }

        // Helper function for calcAreas
        private void correctBoxHeight(int y, int boxHeight)
        {
            int j = tabAreas.Count - 1;
            while (j >= 0 && tabAreas[j].rectangle.Y == y && (tabAreas[j].boxHeight != boxHeight || boxHeight < 5))
            {
                TabArea tabArea = tabAreas[j];
                tabArea.boxHeight = boxHeight;
                tabAreas[j] = tabArea;
                j--;
            }
        }

        public void calcAreas(PuttyProcessCollection processes)
        {
            Graphics g = tabControl.CreateGraphics();
            int width = tabControl.Width;
            int height = tabControl.Height;

            int x = 0;
            int y = 0;
            int w = 100;
            int h = 50;
            int boxHeight = 0;

            TabArea tabArea;

            tabAreas = new Collection<TabArea>();

            foreach (PuttyProcess puttyProcess in processes.getProcesses())
            {
                String text = puttyProcess.DisplayName;

                Size size = TextRenderer.MeasureText(g, text, tabControl.Font, new Size(120, 20), textFormatFlags);
                w = Math.Max(80, size.Width) + 2;
                h = Math.Min(tabMaxHeight, size.Height) + TABHEIGHT_EXTRA;

                if (x > 0 && x + w > tabControl.Width)
                {
                    correctBoxHeight(y, boxHeight);

                    if (x < tabControl.Width)
                    {
                        tabArea = new TabArea();
                        tabArea.rectangle = new Rectangle(x, y, tabControl.Width - x, boxHeight);
                        tabArea.boxHeight = boxHeight;
                        tabAreas.Add(tabArea);
                    }
                    x = 0;
                    y += boxHeight;
                    boxHeight = h;
                }
                else if (h > boxHeight)
                {
                    boxHeight = h;
                    correctBoxHeight(y, boxHeight);
                }

                tabArea = new TabArea();
                tabArea.rectangle = new Rectangle(x, y, w, h);
                tabArea.boxHeight = boxHeight;
                tabArea.process = puttyProcess;
                tabAreas.Add(tabArea);

                x += w;
            }
            correctBoxHeight(y, 2);

            if (x < tabControl.Width) {
                tabArea = new TabArea();
                tabArea.rectangle = new Rectangle(x, y, tabControl.Width - x, 2);
                tabArea.boxHeight = 2;
                tabAreas.Add(tabArea);
            }

            tabControl.Height = Math.Max(28, y + boxHeight);
            tabControl.Invalidate();
        }

        private bool dragging()
        {
            return dragFrom >= 0 && dragStarted;
        }

        public void beginDrag(int x, int y)
        {
            dragFrom = activeTab;
            dragOverTab = -1;
            dragStartX = x;
            dragStartY = y;
            dragStarted = false;
        }
        
        public bool drag(int x, int y)
        {
            if (dragStartX != x || dragStartY != y) dragStarted = true;

            if (!dragging()) return false;

            dragOverTab = calcMouseoverTab();
            return true;
        }

        public bool endDrag(PuttyProcessCollection processes)
        {
            if (dragStarted && dragFrom != dragOverTab && dragOverTab >= 0) {
                processes.move(dragFrom, dragOverTab);
            }
            dragFrom = -1;
            dragOverTab = -1;
            return true;
        }
    }

}
