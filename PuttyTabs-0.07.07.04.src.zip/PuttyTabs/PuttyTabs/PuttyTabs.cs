using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;
using System.Collections.ObjectModel;
using System.Web;
using System.Threading;
using Microsoft.Win32;


// PuttyTabs is copyright 2006 Dietrich Raisin.
// The exact Licence is in Licence.txt.

namespace PuttyTabs
{
    public sealed class Config
    {
        // Zum Start read-only. Bei Form.Shown wird auf rw geschaltet.
        static private bool bReadOnly = true;

        // I really don't know: Is using this location rude or sensible?
        private const string subkeyM = @"Software\SimonTatham\PuTTY\TabGui";

        static public bool ReadOnly
        {
            get { return bReadOnly; }
            set { bReadOnly = value; }
        }

        static private RegistryKey createSubKey()
        {
            RegistryKey rk = Registry.CurrentUser.CreateSubKey(subkeyM);
            if (rk == null)
            {
                Console.WriteLine("Config.createSubKey failed!");
            }
            return rk;
        }

        static public void setStringValue(String sKey, String sValue)
        {
            if (bReadOnly) return;
            RegistryKey rk = createSubKey();
            if (rk != null) rk.SetValue(sKey, sValue);
        }

        static public void setIntValue(String sKey, int iValue)
        {
            if (bReadOnly) return;
            RegistryKey rk = createSubKey();
            if (rk != null) rk.SetValue(sKey, iValue);
        }

        static public string getStringValue(String sKey)
        {
            RegistryKey rk = Registry.CurrentUser.OpenSubKey(subkeyM);
            if (rk == null) return "";
            return (string)rk.GetValue(sKey, "");
        }

        static public int getIntValue(String sKey)
        {
            RegistryKey rk = Registry.CurrentUser.OpenSubKey(subkeyM);
            if (rk == null) return 0;
            try
            {
                return (int)rk.GetValue(sKey, 0);
            }
            catch
            {
                return 0;
            }
        }
    }
    
    public sealed class PuttySession
    {
        static bool changed;
        static int iButtonCounter = 0;
        
        String sName;
        String sHost= "(unknown)";

        Process process;
        Button button;

        const int ERROR_FILE_NOT_FOUND = 2;
        const int ERROR_ACCESS_DENIED = 5;

        public const int BUTTON_WIDTH = 128;
        public const int BUTTON_HEIGHT = 46;

        public PuttySession(String sName)
        {
            this.sName = sName;
            makeButton();
        }

        public String Name
        {
            get { return sName; }
        }

        public String Host
        {
            get { return sHost; }
            set { sHost= value; }
        }

        public Button Button
        {
            get { return button; }
            set { button = value; }
        }

        public Process Process
        {
            get { return process; }
        }

        static public Process StartProcess(String sName)
        {
            Process process = new Process();
            try
            {
                process.StartInfo.FileName = Config.getStringValue("PuttyExe");
                process.StartInfo.Arguments = (sName == "") ? "" : "-load \"" + HttpUtility.UrlDecode(sName) + "\"";
                process.StartInfo.CreateNoWindow = true;
                process.Start();
            }
            catch (Win32Exception e)
            {
                MessageBox.Show("An error occured while launching PuttyTabs. Please check your configuration!\n\r"
                    + "\n\r\"" + e.Message + "\"", "Can't launch PuttyTabs",
                    MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return null;
            }
            return process;
        }

        private void makeButton() {
            iButtonCounter++;
            button = new System.Windows.Forms.Button();
            button.Location = new System.Drawing.Point(3, 3);
            button.Name = "sessionbutton" + iButtonCounter.ToString();
            button.Size = new System.Drawing.Size(BUTTON_WIDTH, BUTTON_HEIGHT);
            button.TabIndex = 0;
            button.Text = HttpUtility.UrlDecode(sName);
            button.UseVisualStyleBackColor = true;
            button.Tag= this;
            button.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            button.Click += new System.EventHandler(this.sessionButton_Click);
            button.Visible = false;
            button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
        }

        private void sessionButton_Click(object sender, EventArgs e)
        {
            PuttySession session= (PuttySession)((Button)sender).Tag;
            if (session == null) return;
            if (session.isStarted())
            {
                Win32Window window = new Win32Window(session.Process.MainWindowHandle);
                if (window.getState() == FormWindowState.Minimized)
                {
                    window.SetState(FormWindowState.Normal);
                }
                window.bringToFront();
            }
            else
            {
                session.start();
            }
            setButtonColor();
        }

        public bool isStarted()
        {
            if (process == null) return false;
            if (process.HasExited) return false;
            return true;
        }

        public void start()
        {
            process = StartProcess(sName);

            // These two calls must be, otherwise process.MainWindowHandle is broken (???)
            process.WaitForInputIdle(1000);
            Thread.Sleep(500);
            
            /*
                        return;
                        
                        if (!startProcess()) return;
                        for (int i = 0; i < 1000; i += 25)
                        {
                            // if ((int)process.MainWindowHandle != 0) break;
                            Thread.Sleep(25);
                        }
                        Win32Window window = new Win32Window(process.MainWindowHandle);
                        window.setSize(100, 100, 600, 600);
                        Console.WriteLine(process.ToString());
            */
        }

        public void setButtonColor() 
        {
            if (process != null && !process.HasExited)
            {
                if ((button.BackColor != System.Drawing.Color.Gold)
                    && (button.BackColor != System.Drawing.Color.Lime))
                {
                    changed= true;
                }
                if (process.MainWindowHandle == Win32Window.getForegroundWindow())
                {
                    button.BackColor = System.Drawing.Color.Lime;
                }
                else
                {
                    button.BackColor = System.Drawing.Color.Gold;
                }
            }
            else
            {
                if (button.BackColor != System.Drawing.Color.Salmon) {
                    changed= true;
                }
                button.BackColor = System.Drawing.Color.Salmon;
            }
        }

        public static bool Changed
        {
            get { bool temp = changed; changed = false; return temp; }
        }
    }

    public sealed class PuttySessionCollection
    {
        ISessionsChangedNotifier sessionsChangedNotifier;

        String sFingerprint= "";
        Collection<PuttySession> sessions = new Collection<PuttySession>();

        public PuttySessionCollection(ISessionsChangedNotifier sessionsChangedNotifier) {
            this.sessionsChangedNotifier = sessionsChangedNotifier;
        }

        public String Fingerprint
        {
            get { return sFingerprint; }
        }

        public String getRegistryFingerprint()
        {
            return _fetchSessions(true);
        }

        public String fetchSessionsFromRegistry()
        {
            return _fetchSessions(false);
        }

        private String _fetchSessions(bool onlyFingerprint)
        {
            if (!onlyFingerprint) {
                sessions.Clear();
            }

            string subkeyM = @"Software\SimonTatham\PuTTY\Sessions";

            RegistryKey rk = Registry.CurrentUser.OpenSubKey(subkeyM);
            if (rk == null) return "";

            string fingerprint = "";
            foreach (string subKeyName in rk.GetSubKeyNames())
            {
                RegistryKey tempKey = rk.OpenSubKey(subKeyName);
                String sHost = (tempKey != null) ? tempKey.GetValue("HostName").ToString() : "";

                if (!onlyFingerprint)
                {
                    PuttySession session = new PuttySession(subKeyName);
                    session.Host = sHost;
                    sessions.Add(session);
                }

                fingerprint += subKeyName + "\0" + sHost + "\0";
            }
            if (!onlyFingerprint)
            {
                sFingerprint = fingerprint;
            }
            return fingerprint;
        }

        public Collection<PuttySession> getSessions()
        {
            return sessions;
        }

        // http://de.wikipedia.org/wiki/Farbtabellen_im_Internet

        public void checkAll()
        {
            foreach (PuttySession session in sessions)
            {
                session.setButtonColor();
            }
            if (PuttySession.Changed)
            {
                sessionsChangedNotifier.sessionsChanged();
            }
        }
    }
    
}