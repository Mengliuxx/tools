﻿namespace PuttyTabs
{
    partial class MainForm
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuPuttyTabs = new System.Windows.Forms.ToolStripMenuItem();
            this.menuNew = new System.Windows.Forms.ToolStripMenuItem();
            this.menuAlwaysOnTop = new System.Windows.Forms.ToolStripMenuItem();
            this.menuMoveOutOfView = new System.Windows.Forms.ToolStripMenuItem();
            this.menuConf = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.menuAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.menuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.closeWindowButton = new System.Windows.Forms.Button();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.addProcessPanel = new System.Windows.Forms.Panel();
            this.addProcessToolStrip = new System.Windows.Forms.ToolStrip();
            this.addProcessButton = new System.Windows.Forms.ToolStripDropDownButton();
            this.textToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tabsLabel = new System.Windows.Forms.Label();
            this.resizeButton = new System.Windows.Forms.Button();
            this.tabAreaContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.findTagMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabAreaTagComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.removeTagMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.cancelMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.menuStrip1.SuspendLayout();
            this.mainPanel.SuspendLayout();
            this.addProcessPanel.SuspendLayout();
            this.addProcessToolStrip.SuspendLayout();
            this.tabAreaContextMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(0);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuPuttyTabs});
            this.menuStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(0);
            this.menuStrip1.Size = new System.Drawing.Size(591, 25);
            this.menuStrip1.TabIndex = 5;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.MenuActivate += new System.EventHandler(this.menuStrip1_MenuActivate);
            this.menuStrip1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.menuStrip1_MouseUp);
            this.menuStrip1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.menuStrip1_MouseMove);
            this.menuStrip1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.menuStrip1_MouseDown);
            this.menuStrip1.MenuDeactivate += new System.EventHandler(this.menuStrip1_MenuDeactivate);
            // 
            // menuPuttyTabs
            // 
            this.menuPuttyTabs.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuNew,
            this.menuAlwaysOnTop,
            this.menuMoveOutOfView,
            this.menuConf,
            this.toolStripSeparator1,
            this.menuAbout,
            this.toolStripSeparator2,
            this.menuExit});
            this.menuPuttyTabs.Name = "menuPuttyTabs";
            this.menuPuttyTabs.Size = new System.Drawing.Size(96, 25);
            this.menuPuttyTabs.Text = "PuttyTabs";
            // 
            // menuNew
            // 
            this.menuNew.Name = "menuNew";
            this.menuNew.Size = new System.Drawing.Size(308, 26);
            this.menuNew.Text = "Open PuTTY Dialog...";
            this.menuNew.Click += new System.EventHandler(this.menuNew_Click);
            // 
            // menuAlwaysOnTop
            // 
            this.menuAlwaysOnTop.Name = "menuAlwaysOnTop";
            this.menuAlwaysOnTop.Size = new System.Drawing.Size(308, 26);
            this.menuAlwaysOnTop.Text = "Always on top";
            this.menuAlwaysOnTop.Click += new System.EventHandler(this.menuAlwaysOnTop_Click);
            // 
            // menuMoveOutOfView
            // 
            this.menuMoveOutOfView.Name = "menuMoveOutOfView";
            this.menuMoveOutOfView.Size = new System.Drawing.Size(308, 26);
            this.menuMoveOutOfView.Text = "Move out of view when docked";
            this.menuMoveOutOfView.Click += new System.EventHandler(this.menuMoveOutOfView_Click);
            // 
            // menuConf
            // 
            this.menuConf.Name = "menuConf";
            this.menuConf.Size = new System.Drawing.Size(308, 26);
            this.menuConf.Text = "Configuration...";
            this.menuConf.Click += new System.EventHandler(this.menuConf_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(305, 6);
            // 
            // menuAbout
            // 
            this.menuAbout.Name = "menuAbout";
            this.menuAbout.Size = new System.Drawing.Size(308, 26);
            this.menuAbout.Text = "About...";
            this.menuAbout.Click += new System.EventHandler(this.menuAbout_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(305, 6);
            // 
            // menuExit
            // 
            this.menuExit.Name = "menuExit";
            this.menuExit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.menuExit.Size = new System.Drawing.Size(308, 26);
            this.menuExit.Text = "Exit";
            this.menuExit.Click += new System.EventHandler(this.menuExit_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 50;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // closeWindowButton
            // 
            this.closeWindowButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.closeWindowButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeWindowButton.Location = new System.Drawing.Point(568, 2);
            this.closeWindowButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.closeWindowButton.Name = "closeWindowButton";
            this.closeWindowButton.Size = new System.Drawing.Size(20, 20);
            this.closeWindowButton.TabIndex = 0;
            this.closeWindowButton.Text = "X";
            this.closeWindowButton.UseVisualStyleBackColor = true;
            this.closeWindowButton.Click += new System.EventHandler(this.closeWindowButton_Click);
            // 
            // mainPanel
            // 
            this.mainPanel.BackColor = System.Drawing.SystemColors.Control;
            this.mainPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.mainPanel.Controls.Add(this.addProcessPanel);
            this.mainPanel.Controls.Add(this.closeWindowButton);
            this.mainPanel.Controls.Add(this.menuStrip1);
            this.mainPanel.Controls.Add(this.tabsLabel);
            this.mainPanel.Controls.Add(this.resizeButton);
            this.mainPanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.mainPanel.Location = new System.Drawing.Point(0, 0);
            this.mainPanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(593, 221);
            this.mainPanel.TabIndex = 7;
            // 
            // addProcessPanel
            // 
            this.addProcessPanel.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.addProcessPanel.Controls.Add(this.addProcessToolStrip);
            this.addProcessPanel.Location = new System.Drawing.Point(32, 153);
            this.addProcessPanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.addProcessPanel.Name = "addProcessPanel";
            this.addProcessPanel.Size = new System.Drawing.Size(40, 33);
            this.addProcessPanel.TabIndex = 13;
            // 
            // addProcessToolStrip
            // 
            this.addProcessToolStrip.CanOverflow = false;
            this.addProcessToolStrip.Dock = System.Windows.Forms.DockStyle.None;
            this.addProcessToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addProcessButton});
            this.addProcessToolStrip.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.addProcessToolStrip.Location = new System.Drawing.Point(0, 1);
            this.addProcessToolStrip.Name = "addProcessToolStrip";
            this.addProcessToolStrip.Size = new System.Drawing.Size(30, 23);
            this.addProcessToolStrip.TabIndex = 12;
            this.addProcessToolStrip.Text = "toolStrip1";
            // 
            // addProcessButton
            // 
            this.addProcessButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.addProcessButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.textToolStripMenuItem,
            this.toolStripSeparator3});
            this.addProcessButton.Image = ((System.Drawing.Image)(resources.GetObject("addProcessButton.Image")));
            this.addProcessButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.addProcessButton.Name = "addProcessButton";
            this.addProcessButton.Size = new System.Drawing.Size(29, 20);
            this.addProcessButton.Text = "toolStripDropDownButton1";
            this.addProcessButton.ToolTipText = "Open PuTTY Session";
            this.addProcessButton.DropDownClosed += new System.EventHandler(this.addProcessButton_DropDownClosed);
            this.addProcessButton.DropDownOpening += new System.EventHandler(this.addProcessButton_DropDownOpening);
            // 
            // textToolStripMenuItem
            // 
            this.textToolStripMenuItem.Name = "textToolStripMenuItem";
            this.textToolStripMenuItem.Size = new System.Drawing.Size(109, 26);
            this.textToolStripMenuItem.Text = "text";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(106, 6);
            // 
            // tabsLabel
            // 
            this.tabsLabel.BackColor = System.Drawing.SystemColors.Window;
            this.tabsLabel.Location = new System.Drawing.Point(61, 28);
            this.tabsLabel.Name = "tabsLabel";
            this.tabsLabel.Size = new System.Drawing.Size(475, 110);
            this.tabsLabel.TabIndex = 9;
            this.tabsLabel.MouseLeave += new System.EventHandler(this.tabsLabel_MouseLeave);
            this.tabsLabel.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tabsLabel_MouseDown);
            this.tabsLabel.MouseMove += new System.Windows.Forms.MouseEventHandler(this.tabsLabel_MouseMove);
            this.tabsLabel.MouseEnter += new System.EventHandler(this.tabsLabel_MouseEnter);
            this.tabsLabel.Paint += new System.Windows.Forms.PaintEventHandler(this.tabsLabel_Paint);
            this.tabsLabel.MouseUp += new System.Windows.Forms.MouseEventHandler(this.tabsLabel_MouseUp);
            // 
            // resizeButton
            // 
            this.resizeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resizeButton.Location = new System.Drawing.Point(541, 46);
            this.resizeButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.resizeButton.Name = "resizeButton";
            this.resizeButton.Size = new System.Drawing.Size(21, 21);
            this.resizeButton.TabIndex = 7;
            this.resizeButton.TabStop = false;
            this.resizeButton.Text = "»";
            this.resizeButton.UseVisualStyleBackColor = true;
            this.resizeButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.resizeButton_MouseDown);
            this.resizeButton.MouseMove += new System.Windows.Forms.MouseEventHandler(this.resizeButton_MouseMove);
            this.resizeButton.MouseUp += new System.Windows.Forms.MouseEventHandler(this.resizeButton_MouseUp);
            // 
            // tabAreaContextMenuStrip
            // 
            this.tabAreaContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.findTagMenuItem,
            this.tabAreaTagComboBox,
            this.removeTagMenuItem,
            this.toolStripSeparator4,
            this.cancelMenuItem});
            this.tabAreaContextMenuStrip.Name = "tabAreaContextMenuStrip";
            this.tabAreaContextMenuStrip.ShowImageMargin = false;
            this.tabAreaContextMenuStrip.Size = new System.Drawing.Size(278, 121);
            this.tabAreaContextMenuStrip.MouseClick += new System.Windows.Forms.MouseEventHandler(this.tabAreaContextMenuStrip_MouseClick);
            // 
            // findTagMenuItem
            // 
            this.findTagMenuItem.Enabled = false;
            this.findTagMenuItem.Name = "findTagMenuItem";
            this.findTagMenuItem.Size = new System.Drawing.Size(277, 26);
            this.findTagMenuItem.Text = "Find tag or enter new:";
            // 
            // tabAreaTagComboBox
            // 
            this.tabAreaTagComboBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.tabAreaTagComboBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.tabAreaTagComboBox.FlatStyle = System.Windows.Forms.FlatStyle.Standard;
            this.tabAreaTagComboBox.Items.AddRange(new object[] {
            "sdfdgdsfg",
            "sdfgdfg",
            "sdfg",
            "sdfgsdfgsd",
            "sdfgdf"});
            this.tabAreaTagComboBox.MaxDropDownItems = 20;
            this.tabAreaTagComboBox.Name = "tabAreaTagComboBox";
            this.tabAreaTagComboBox.Size = new System.Drawing.Size(221, 29);
            this.tabAreaTagComboBox.ToolTipText = resources.GetString("tabAreaTagComboBox.ToolTipText");
            this.tabAreaTagComboBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tabAreaTagComboBox_KeyDown);
            this.tabAreaTagComboBox.SelectedIndexChanged += new System.EventHandler(this.tabAreaTagComboBox_SelectedIndexChanged);
            // 
            // removeTagMenuItem
            // 
            this.removeTagMenuItem.Name = "removeTagMenuItem";
            this.removeTagMenuItem.Size = new System.Drawing.Size(277, 26);
            this.removeTagMenuItem.Text = "Remove selected tag from list";
            this.removeTagMenuItem.Click += new System.EventHandler(this.removeTagMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(274, 6);
            // 
            // cancelMenuItem
            // 
            this.cancelMenuItem.Name = "cancelMenuItem";
            this.cancelMenuItem.Size = new System.Drawing.Size(277, 26);
            this.cancelMenuItem.Text = "Cancel";
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.BalloonTipTitle = "PuttyTabs - Click to bring to front.";
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "PuttyTabs";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.Click += new System.EventHandler(this.notifyIcon1_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(632, 439);
            this.Controls.Add(this.mainPanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "MainForm";
            this.ShowInTaskbar = false;
            this.Text = "PuttyTabs";
            this.Resize += new System.EventHandler(this.Form1_Resize);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.Activated += new System.EventHandler(this.Form1_Activated);
            this.Move += new System.EventHandler(this.Form1_Move);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            this.addProcessPanel.ResumeLayout(false);
            this.addProcessPanel.PerformLayout();
            this.addProcessToolStrip.ResumeLayout(false);
            this.addProcessToolStrip.PerformLayout();
            this.tabAreaContextMenuStrip.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuPuttyTabs;
        private System.Windows.Forms.ToolStripMenuItem menuNew;
        private System.Windows.Forms.ToolStripMenuItem menuConf;
        private System.Windows.Forms.ToolStripMenuItem menuAlwaysOnTop;
        private System.Windows.Forms.ToolStripMenuItem menuAbout;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem menuExit;
        private System.Windows.Forms.Button closeWindowButton;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.Button resizeButton;
        private System.Windows.Forms.ToolStripMenuItem menuMoveOutOfView;
        private System.Windows.Forms.Label tabsLabel;
        private System.Windows.Forms.ToolStrip addProcessToolStrip;
        private System.Windows.Forms.ToolStripDropDownButton addProcessButton;
        private System.Windows.Forms.ToolStripMenuItem textToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.Panel addProcessPanel;
        private System.Windows.Forms.ContextMenuStrip tabAreaContextMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem findTagMenuItem;
        private System.Windows.Forms.ToolStripComboBox tabAreaTagComboBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem cancelMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeTagMenuItem;
        private System.Windows.Forms.NotifyIcon notifyIcon1;
    }
}

