using System;
using System.Collections.Generic;
// using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Diagnostics;
using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.Drawing.Drawing2D;

// PuttyTabs is copyright 2006 Dietrich Raisin.
// The exact Licence is in Licence.txt.

// TODO: quickSessions: Sessions, die �ber "New Session" dazugekommen sind, anzeigen

// http://de.wikipedia.org/wiki/Farbtabellen_im_Internet

namespace PuttyTabs
{
    public partial class MainForm : Form
    {
        public PuttySessionCollection regSessions;
        public PuttyProcessCollection processes;

        int timer1Count;

        int moveWindowClickX, moveWindowClickY;
        int moveWindowInitialX, moveWindowInitialY;

        int swooshX, swooshY, unswooshX, unswooshY;
        int swooshTimerCount;

        bool menuIsOpen;
        bool noSwooshAndSessionSelectorIsOpen;

        int processesTimerCount;

        TabAreaControl tabAreas;

        Rectangle virtualScreen= SystemInformation.VirtualScreen;
        Control tabControl;

        /**
         *  Form Stuff
         */

        public MainForm()
        {
            InitializeComponent();
            regSessions = new PuttySessionCollection(this);
            processes = new PuttyProcessCollection();
            tabControl = (Control)tabsLabel;
            tabAreas= new TabAreaControl(tabControl);
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            // Form1_Resize(sender, e);

            calcTabAreas();
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            Config.setIntValue("windowWidth", this.Width);
            Config.setIntValue("windowHeight", this.Height);

            mainPanel.Dock = DockStyle.Fill;

            // Sometimes Resize is called during InitializeComponent? strange!
            // Workaround this:
            if (tabAreas == null) return;

            calcTabAreas();
            correctLayout(false);
        }

        private void correctLayout(bool buildRegion)
        {
            int x0 = 1;
            int y0 = tabControl.Top + 1;
            int w0 = tabControl.Parent.Width;

            int w1 = addProcessToolStrip.Width + 2;
            int h1 = addProcessToolStrip.Height + 2;

            addProcessPanel.Left = 0;
            addProcessPanel.Top = y0;
            addProcessPanel.Width = w1;
            addProcessPanel.Height = h1;

            tabControl.Left = x0 + w1;
            tabControl.Width = w0 - resizeButton.Width - w1 - 2;

            int w2 = resizeButton.Width;
            int x2 = w0 - w2;
            int h2 = resizeButton.Height;

            resizeButton.Left = x2;
            resizeButton.Top = y0;

            if (buildRegion)
            {
                if (swooshY < 0 && Top == swooshY)
                {
                    GraphicsPath gp = new GraphicsPath();
                    // Title-Bar
                    gp.AddRectangle(new Rectangle(0, y0, w1, h1));
                    // addProcess-Button
                    gp.AddRectangle(new Rectangle(0, 0, w0, y0));
                    gp.AddRectangle(new Rectangle(1, y0 + h1, w1 - 2, 1));
                    // resize-Button
                    gp.AddRectangle(new Rectangle(x2, y0, w2, h2));
                    // g.FillPath(Brushes.Black, gp);

                    tabAreas.paint(tabControl.CreateGraphics(), gp, true);

                    // g.FillPath(Brushes.Black, gp);
                    Region region = new Region(gp);
                    this.Region = new Region(gp);
                }
                else
                {
                    this.Region = null;
                }
            }
        }

        private void Form1_Move(object sender, EventArgs e)
        {
            Config.setIntValue("windowLeft", this.Left);
            Config.setIntValue("windowTop", this.Top);
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            Win32Window mainWindow = new Win32Window(this.Handle);
            mainWindow.hideFromTaskSwitcher();

            // Set initial Config Values if initialized is 0
            if (Config.getIntValue("initialized") == 0)
            {
                Rectangle area = Screen.GetWorkingArea(this);
                Config.ReadOnly = false;
                Config.setIntValue("windowLeft", area.Width / 2 - 150);
                Config.setIntValue("windowTop", area.Height / 2 - 100);
                Config.setIntValue("windowWidth", 300);
                Config.setIntValue("windowHeight", 200);
                Config.setIntValue("alwaysOnTop", 1);
                Config.setIntValue("moveOutOfView", 1);
                Config.setIntValue("initialized", 1);
                Config.ReadOnly = true;
            }

            setSnappedPosition(
                Config.getIntValue("windowLeft"),
                Config.getIntValue("windowTop"),
                Config.getIntValue("windowWidth"),
                Config.getIntValue("windowHeight"),
                false, false
            );

            // New version has to set a new default value
            if (Config.getIntValue("initialized") == 1)
            {
                MessageBox.Show("This version of PuttyTabs now automatically imports PuTTY\r\n"
                    + " sessions that were started before PuttyTabs was launched.\r\n\r\n"
                    + " If you don't want that, you can turn this behaviour off in the\r\n"
                    + " configuration dialog.", "PuttyTabs News!");
                Config.ReadOnly = false;
                Config.setIntValue("importPuttyProcesses", 1);
                Config.setIntValue("initialized", 2);
                Config.ReadOnly = true;
            }

            setAlwaysOnTop();

            if (Config.getIntValue("importPuttyProcesses") != 0)
            {
                processes.fetchRunningPuttys();
            }

            Config.ReadOnly = false;
        }


        /**
         *  Menu Stuff
         */

        private void menuStrip1_MenuActivate(object sender, EventArgs e)
        {
            menuAlwaysOnTop.Checked = Config.getIntValue("alwaysOnTop") != 0;
            menuMoveOutOfView.Checked = Config.getIntValue("moveOutOfView") != 0;
            menuIsOpen = true;
        }

        private void menuStrip1_MenuDeactivate(object sender, EventArgs e)
        {
            menuIsOpen = false;
        }

        private void menuNew_Click(object sender, EventArgs e)
        {
            processes.startProcess(this);
        }

        private void menuConf_Click(object sender, EventArgs e)
        {
            ConfigForm configForm = new ConfigForm();
            configForm.show();
            setAlwaysOnTop();
        }

        private void menuAlwaysOnTop_Click(object sender, EventArgs e)
        {
            Config.setIntValue("alwaysOnTop", Config.getIntValue("alwaysOnTop") == 0 ? 1 : 0);
            setAlwaysOnTop();
        }

        private void menuMoveOutOfView_Click(object sender, EventArgs e)
        {
            Config.setIntValue("moveOutOfView", Config.getIntValue("moveOutOfView") == 0 ? 1 : 0);
        }

        private void menuAbout_Click(object sender, EventArgs e)
        {
            AboutForm aboutForm = new AboutForm();
            aboutForm.show();
        }

        private void menuExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        /**
         *  Move Window
         */

        private void menuStrip1_MouseDown(object sender, MouseEventArgs e)
        {
            menuStrip1.Capture = e.Button == MouseButtons.Left;
            if (menuStrip1.Capture)
            {
                Point senderScreenPos = ((Control)sender).PointToScreen(new Point(e.X, e.Y));

                moveWindowInitialX = Left;
                moveWindowInitialY = Top;
                moveWindowClickX = senderScreenPos.X;
                moveWindowClickY = senderScreenPos.Y;
            }
        }

        private void menuStrip1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
            {
                menuStrip1.Capture = false;
                return;
            }
            if (menuStrip1.Capture)
            {
                Point senderScreenPos = ((Control)sender).PointToScreen(new Point(e.X, e.Y));
                setSnappedPosition(
                    senderScreenPos.X - moveWindowClickX + moveWindowInitialX,
                    senderScreenPos.Y - moveWindowClickY + moveWindowInitialY,
                    Width, Height, true, false
                );
            }
        }

        private void menuStrip1_MouseUp(object sender, MouseEventArgs e)
        {
            menuStrip1.Capture = false;
        }

        /**
         *  Close Button
         */

        private void closeWindowButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        /**
         *  Resize Window
         */

        private void resizeButton_MouseDown(object sender, MouseEventArgs e)
        {
            resizeButton.Capture = e.Button == MouseButtons.Left;
            if (resizeButton.Capture)
            {
                Point senderScreenPos = ((Control)sender).PointToScreen(new Point(e.X, e.Y));

                moveWindowInitialX = Width;
                moveWindowInitialY = Height;
                moveWindowClickX = senderScreenPos.X;
                moveWindowClickY = senderScreenPos.Y;
            }
        }

        private void resizeButton_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button != MouseButtons.Left)
            {
                resizeButton.Capture = false;
                return;
            }
            if (resizeButton.Capture)
            {
                Point senderScreenPos = ((Control)sender).PointToScreen(new Point(e.X, e.Y));
                Width= senderScreenPos.X - moveWindowClickX + moveWindowInitialX;
            }
        }

        private void resizeButton_MouseUp(object sender, MouseEventArgs e)
        {
            resizeButton.Capture = false;
            Point senderScreenPos = ((Control)sender).PointToScreen(new Point(e.X, e.Y));
            setSnappedPosition(Left, Top,
                senderScreenPos.X - moveWindowClickX + moveWindowInitialX,
                moveWindowInitialY,
                false, true
            );
            correctLayout(true);
        }

        /**
         *  Misc Stuff
         */

        public void setAlwaysOnTop()
        {
            TopMost = Config.getIntValue("alwaysOnTop") != 0;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1Count += timer1.Interval;

            if (processesTimerCount < timer1Count)
            {
                if (processes != null)
                {
                    if (processes.processHasChanged()) {
                        calcTabAreas();
                    }
                }
                processesTimerCount= timer1Count + 500;

                if (!virtualScreen.Equals(SystemInformation.VirtualScreen))
                {
                    virtualScreen = SystemInformation.VirtualScreen;
                    setSnappedPosition();
                }
            }

            if (swooshX != 0)
            {
                int swooshTo = (Bounds.Contains(Control.MousePosition) || Config.getIntValue("moveOutOfView") == 0) ? unswooshX : swooshX;
                int step = Math.Max(Math.Abs(swooshTo - Left) / 5, 10);
                Left = (swooshTo < Left) ? Math.Max(swooshTo, Left - step) : Math.Min(swooshTo, Left + step);
            }
            if (swooshY != 0)
            {
                int swooshTo = swooshY;
                if (Bounds.Contains(Control.MousePosition)) {
                    if (Control.MousePosition.Y < 3 && Top == swooshY) swooshTo= unswooshY;
                    if (Top != swooshY) swooshTo = unswooshY;
                }
                if (menuIsOpen || noSwooshAndSessionSelectorIsOpen) swooshTo = unswooshY;
                if (Config.getIntValue("moveOutOfView") == 0) swooshTo= unswooshY;
                if (swooshTo != swooshY)
                {
                    if (swooshTimerCount >= timer1Count)
                    {
                        swooshTo = swooshY;
                    }
                }
                else
                {
                    swooshTimerCount = timer1Count + 300;
                }
                int step = Math.Max(Math.Abs(swooshTo - Top) / 5, 10);
                int lastTop = Top;
                Top = (swooshTo < Top) ? Math.Max(swooshTo, Top - step) : Math.Min(swooshTo, Top + step);
                if (Top != lastTop)
                {
                    correctLayout(true);
                }
            }
        }

        private void setSnappedPosition()
        {
            setSnappedPosition(Left, Top, Width, Height, false, false);
        }

        private void setSnappedPosition(int left, int top, int width, int height, bool snapMove, bool snapResize)
        {
            const int SNAP = 16;
            const int MINWIDTH = 120;
            const int MINHEIGHT = 50;
            const int SWOOSH = 10;

            // MyRectangle area = new MyRectangle(Screen.AllScreens[0].WorkingArea);
            MyRectangle area = new MyRectangle(SystemInformation.VirtualScreen);
            MyRectangle result = new MyRectangle(new Rectangle(left, top, width, height));

            if (result.width < MINWIDTH) result.width = MINWIDTH;
            if (result.width > area.width) result.width = area.width;
            if (result.height < MINHEIGHT) result.height = MINHEIGHT;
            if (result.height > area.height) result.height = area.height;

            if (result.left < area.left) result.left = area.left;
            if (result.top < area.top) result.top = area.top;
            if (snapMove)
            {
                if (Math.Abs(result.left - area.left) < SNAP) result.left = area.left;
                if (Math.Abs(result.top - area.top) < SNAP) result.top = area.top;
                if (Math.Abs(result.right - area.right) < SNAP) result.left = area.right - result.width + 1;
                if (Math.Abs(result.bottom - area.bottom) < SNAP) result.top = area.bottom - result.height + 1;
            }

            if (result.right > area.right) result.left = area.right - result.width + 1;
            if (result.top > area.bottom - MINHEIGHT) result.top = area.bottom - MINHEIGHT;
            if (snapResize)
            {
                if (Math.Abs(result.right - area.right) < SNAP) result.right = area.right;
                if (Math.Abs(result.bottom - area.bottom) < SNAP) result.bottom = area.bottom;
            }

            unswooshX = result.left;
            swooshX= 0;
            if (result.left == area.left) swooshX= area.left - result.width + SWOOSH;
            if (result.right == area.right) swooshX= area.right - SWOOSH;

            unswooshY = result.top;
            swooshY = 0;
            if (result.top == area.top)
            {
                swooshY = area.top - tabControl.Top + 2;
                // swooshY = area.top - result.height + SWOOSH;
            }
            // No swoothing downwards:
            // if (result.bottom == area.bottom) swooshY = area.bottom - SWOOSH;

            Left = result.left;
            Top = result.top;
            Width = result.width;
            Height = result.height;
        }

        private void tabsLabel_Paint(object sender, PaintEventArgs e)
        {
            tabAreas.paint(e.Graphics);
        }

        private void tabsLabel_MouseLeave(object sender, EventArgs e)
        {
            tabAreas.updateActiveTab();
        }

        private void calcTabAreas()
        {
            tabAreas.calcAreas(processes);
            Height = tabControl.Top + tabControl.Height + Height - ClientRectangle.Height + 2;
            correctLayout(true);
        }

        private void tabsLabel_MouseDown(object sender, MouseEventArgs e)
        {            
            PuttyProcess process = tabAreas.ActiveProcess;
            if (process == null) return;
            if (e.Button == MouseButtons.Left)
            {
                tabAreas.beginDrag(e.X, e.Y);
                
                // if it's in the background, bring it forward. otherwise, send it back.
                if (process.isMinimized() == false)
                {
                	process.toBackground();
                }
                else
                {
					process.startOrActivate();                	
                }

                calcTabAreas();
                tabsLabel.Capture = true;
            }
            else if (e.Button == MouseButtons.Right)
            {
                setupTabAreaContextMenu();
                tabAreaContextMenuStrip.Show((Control)sender, e.X - tabAreaContextMenuStrip.Width + 32, e.Y - 32);
            }
        }

        private void tabsLabel_MouseMove(object sender, MouseEventArgs e)
        {
           	 if (tabAreas.drag(e.X, e.Y))
            {
                correctLayout(true);
                tabControl.Refresh();
            }
            tabAreas.updateActiveTab();
        }

        private void tabsLabel_MouseUp(object sender, MouseEventArgs e)
        {
            tabsLabel.Capture = false;
            if (tabAreas.endDrag(processes))
            {
                calcTabAreas();
                tabControl.Refresh();
            }
        }

        private void tabsLabel_MouseEnter(object sender, EventArgs e)
        {
            tabAreas.updateActiveTab();
        }

        private void addToProcessDropDown(PuttySession session, String text, String toolTip)
        {
            ToolStripMenuItem menuItem = new ToolStripMenuItem();
            menuItem.Name = "textToolStripMenuItem1";
            menuItem.Size = new System.Drawing.Size(152, 26);
            menuItem.Text = text;
            menuItem.ToolTipText = toolTip;
            menuItem.Click += new System.EventHandler(addProcessMenuItem_Click);
            menuItem.Tag = session;
            addProcessButton.DropDownItems.Add(menuItem);
        }

        private void addProcessButton_DropDownOpening(object sender, EventArgs e)
        {
            regSessions.fetchSessionsFromRegistry();

            this.addProcessButton.DropDownItems.Clear();
            foreach (PuttySession session in regSessions.getSessions())
            {
                addToProcessDropDown(session, session.DisplayName, "Host: " + session.Host);
            }
            addProcessButton.DropDownItems.Add(new ToolStripSeparator());
            addToProcessDropDown(null, "PuTTY Dialog", "Open PuTTY Configuration Dialog Window");
            noSwooshAndSessionSelectorIsOpen = (Top != swooshY) && (Left != swooshX);
        }

        private void addProcessButton_DropDownClosed(object sender, EventArgs e)
        {
            noSwooshAndSessionSelectorIsOpen = false;
        }

        private void addProcessMenuItem_Click(object sender, EventArgs e)
        {
        	// avoid a System.InvalidOperationException
        	if (Config.getStringValue("PuttyExe") == "")
        	{
        		MessageBox.Show("You have not configured the path to your PuTTY executable!");
        		return;
        	}

            if (((ToolStripItem)sender).Tag is PuttySession)
            {
                PuttySession session = (PuttySession)((ToolStripItem)sender).Tag;
                processes.startProcess(session);
            }
            else
            {
                processes.startProcess(this);
            }
            calcTabAreas();
        }

        private List<String> getTags()
        {
            return Config.getStringListValue("tags");
        }

        private int compareTagLRU(String a, String b)
        {
            return -String.Compare(a, b, true);
        }

        private int compareTagAlpha(String a, String b)
        {
            return String.Compare(a.Substring(a.IndexOf('|') + 1), b.Substring(b.IndexOf('|') + 1), true);
        }

        private void setupTabAreaContextMenu()
        {
            PuttyProcess process = tabAreas.ActiveProcess;
            tabAreaTagComboBox.Text= process != null ? process.Tag : "";

            List<String> oTags= getTags();

            tabAreaTagComboBox.Items.Clear();
            tabAreaTagComboBox.Items.Add("(None)");
            if (oTags.Count >= 10)
            {
                tabAreaTagComboBox.Items.Add("------ Last recently used");
                oTags.Sort(compareTagLRU);
                for (int i = 0; i < 5 && i < oTags.Count; i++)
                {
                    String sTag = oTags[i];
                    String[] aTag = sTag.Split('|');
                    if (aTag.Length < 2) continue;

                    tabAreaTagComboBox.Items.Add(aTag[1]);
                }
                tabAreaTagComboBox.Items.Add("------ Alphabetically");
            }
            oTags.Sort(compareTagAlpha);
            foreach (String sTag in oTags)
            {
                String[] aTag = sTag.Split('|');
                if (aTag.Length < 2) continue;

                tabAreaTagComboBox.Items.Add(aTag[1]);
            }

            // moreMenuItem.Visible = !bEmpty;
        }

        private void tagEntered(bool remove) {
            
            if (!remove) tabAreaContextMenuStrip.Close();

            String sNewTag = tabAreaTagComboBox.Text.Replace("|", "").Replace("\n", "").Trim();
            if (sNewTag == "" || sNewTag.StartsWith("----")) return;

            int i= -1;
            int iFound = -1;
            int iFoundEmpty = -1;
            int iFoundNone = -1;

            if (sNewTag == "(None)") remove= true;
            
            List<String> oTags= getTags();
            foreach (String sTag in oTags)
            {
                i++;
                String[] aTag = sTag.Split('|');
                if (aTag.Length < 2) continue;
                if (aTag[1] == "") iFoundEmpty = i;
                if (aTag[1] == "(None)") iFoundEmpty = i;
                if (aTag[1] == sNewTag)
                {
                    iFound = i;
                    break;
                }
            }
            if (iFound < 0) iFound = iFoundEmpty; // reuse empty slots (was a bug)
            if (iFound < 0) iFound = iFoundNone;  // reuse None slots (was a bug)
            if (iFound < 0)
            {
                oTags.Add("");
                iFound = oTags.Count - 1;
            }

            if (remove)
            {
                oTags.RemoveAt(iFound);
                sNewTag = "";
            }
            else
            {
                oTags[iFound] = DateTime.Now.ToString("s") + "|" + sNewTag;
            }

            PuttyProcess process = tabAreas.ActiveProcess;
            if (process != null)
            {
                process.Tag = sNewTag;
                calcTabAreas();
            }

            Config.setStringListValue("tags", oTags);
        }

        private void tabAreaTagComboBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                tagEntered(false);
            }
        }

        private void tabAreaTagComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            tagEntered(false);
        }

        private void removeTagMenuItem_Click(object sender, EventArgs e)
        {
            tagEntered(true);
        }

        private void notifyIcon1_Click(object sender, EventArgs e)
        {
            Activate();
        }

        private void tabAreaContextMenuStrip_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                tabAreaContextMenuStrip.Close();
            }
        }
    }

    /**
     *  Reinvented the wheel here, because Rectangle always told me
     *  that Left, Top etc are read only (???)
     */

    struct MyRectangle
    {
        public int left, top, width, height;
        public MyRectangle(Rectangle rectangle)
        {
            left = rectangle.Left;
            top = rectangle.Top;
            width = rectangle.Width;
            height = rectangle.Height;
        }
        public int right
        {
            get { return left + width - 1; }
            set { width = value - left + 1; }
        }
        public int bottom
        {
            get { return top + height - 1; }
            set { width = value - top + 1; }
        }
    }

}
