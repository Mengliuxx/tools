using System;
using System.Collections.Generic;
//using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

//using System.Diagnostics;
//using System.Collections.ObjectModel;
//using System.Web;
//using System.Threading;
using Microsoft.Win32;


// PuttyTabs is copyright 2006 Dietrich Raisin.
// The exact Licence is in Licence.txt.

namespace PuttyTabs
{
    public sealed class Config
    {
        // Zum Start read-only. Bei Form.Shown wird auf rw geschaltet.
        static private bool bReadOnly = true;

        // I really don't know: Is using this location rude or sensible?
        private const string subkeyM = @"Software\SimonTatham\PuTTY\TabGui";

        static public bool ReadOnly
        {
            get { return bReadOnly; }
            set { bReadOnly = value; }
        }

        static private RegistryKey createSubKey()
        {
            RegistryKey rk = Registry.CurrentUser.CreateSubKey(subkeyM);
            if (rk == null)
            {
                Console.WriteLine("Config.createSubKey failed!");
            }
            return rk;
        }

        static public void setStringValue(String sKey, String sValue)
        {
            if (bReadOnly) return;
            RegistryKey rk = createSubKey();
            if (rk != null) rk.SetValue(sKey, sValue);
        }

        static public void setIntValue(String sKey, int iValue)
        {
            if (bReadOnly) return;
            RegistryKey rk = createSubKey();
            if (rk != null) rk.SetValue(sKey, iValue);
        }

        static public string getStringValue(String sKey)
        {
            RegistryKey rk = Registry.CurrentUser.OpenSubKey(subkeyM);
            if (rk == null) return "";
            return (string)rk.GetValue(sKey, "");
        }

        static public int getIntValue(String sKey)
        {
            RegistryKey rk = Registry.CurrentUser.OpenSubKey(subkeyM);
            if (rk == null) return 0;
            try
            {
                return (int)rk.GetValue(sKey, 0);
            }
            catch
            {
                return 0;
            }
        }

        static public List<String> getStringListValue(String sKey)
        {
            List<String> oResult= new List<String>();
            oResult.AddRange(getStringValue(sKey).Split(new char[] {'\n'}));
            return oResult;
        }

        static public void setStringListValue(String sKey, String[] aValues)
        {
            setStringValue(sKey, String.Join("\n", aValues));
        }

        static public void setStringListValue(String sKey, List<String> oValues)
        {
            String[] aValues= new String[oValues.Count];
            oValues.CopyTo(aValues, 0);
            setStringListValue(sKey, aValues);
        }

    }

}